// =============================================================================
// GETINLINE FLUTTER - screens/organization/join_organization_screen.dart
// Join Organization via QR Scanner with Complete Validation
// =============================================================================

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import '../../providers/auth_provider.dart';
import '../../providers/organization_provider.dart';
import '../../models/organization_model.dart';
import '../../utils/constants.dart';
import '../../utils/helpers.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/loading_widget.dart';
import 'admin_dashboard.dart';
import 'create_organization_screen.dart';

class JoinOrganizationScreen extends StatefulWidget {
  const JoinOrganizationScreen({Key? key}) : super(key: key);

  @override
  State<JoinOrganizationScreen> createState() => _JoinOrganizationScreenState();
}

class _JoinOrganizationScreenState extends State<JoinOrganizationScreen> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  QRViewController? controller;
  OrganizationModel? scannedOrganization;
  bool isScanning = true;
  bool isLoading = false;
  bool requestSent = false;

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Join Organization'),
        actions: [
          if (scannedOrganization != null)
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: _resetScan,
              tooltip: 'Scan Again',
            ),
        ],
      ),
      body: scannedOrganization == null
          ? _buildQRScanner()
          : _buildOrganizationDetails(),
    );
  }

  Widget _buildQRScanner() {
    return Column(
      children: [
        // Instructions
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          color: AppColors.primary.withOpacity(0.1),
          child: Column(
            children: [
              const Icon(
                Icons.qr_code_scanner,
                size: 48,
                color: AppColors.primary,
              ),
              const SizedBox(height: 12),
              const Text(
                'Scan Organization QR Code',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Point your camera at the QR code provided by the organization',
                style: TextStyle(
                  fontSize: 14,
                  color: AppColors.textSecondary,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),

        // QR Scanner
        Expanded(
          flex: 3,
          child: QRView(
            key: qrKey,
            onQRViewCreated: _onQRViewCreated,
            overlay: QrScannerOverlayShape(
              borderColor: AppColors.primary,
              borderRadius: 10,
              borderLength: 30,
              borderWidth: 10,
              cutOutSize: MediaQuery.of(context).size.width * 0.7,
            ),
          ),
        ),

        // Bottom Actions
        Expanded(
          flex: 1,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Align the QR code within the frame',
                  style: TextStyle(
                    fontSize: 14,
                    color: AppColors.textSecondary,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                TextButton.icon(
                  onPressed: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const CreateOrganizationScreen(),
                      ),
                    );
                  },
                  icon: const Icon(Icons.add_business),
                  label: const Text('Create New Organization'),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildOrganizationDetails() {
    if (isLoading) {
      return const LoadingWidget(message: 'Loading organization details...');
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Success Icon
          Center(
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.success.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.check_circle,
                size: 60,
                color: AppColors.success,
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Organization Info Card
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Organization Image
                  if (scannedOrganization!.hasPicture) ...[
                    Center(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          scannedOrganization!.picUrl!,
                          height: 100,
                          width: 100,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              height: 100,
                              width: 100,
                              color: AppColors.primary.withOpacity(0.1),
                              child: const Icon(
                                Icons.business,
                                size: 50,
                                color: AppColors.primary,
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // Organization Name
                  Text(
                    scannedOrganization!.organizationName,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Details
                  _buildDetailRow(
                    Icons.phone,
                    'Mobile',
                    StringHelper.formatMobileNumber(scannedOrganization!.mobile),
                  ),
                  const SizedBox(height: 12),
                  _buildDetailRow(
                    Icons.location_on,
                    'Address',
                    scannedOrganization!.address,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Request Status
          if (requestSent)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.success.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppColors.success.withOpacity(0.3),
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.check_circle,
                    color: AppColors.success,
                    size: 24,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Request Sent!',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: AppColors.success,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Your join request has been sent to the organization admin. You will be notified once it\'s approved.',
                          style: TextStyle(
                            fontSize: 13,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )
          else
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.info.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppColors.info.withOpacity(0.3),
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.info_outline,
                    color: AppColors.info,
                    size: 24,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Click below to send a join request to this organization. The admin will review and approve your request.',
                      style: TextStyle(
                        fontSize: 13,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 24),

          // Action Buttons
          if (!requestSent) ...[
            CustomButton(
              text: 'Send Join Request',
              icon: Icons.send,
              onPressed: _handleSendJoinRequest,
              isLoading: isLoading,
            ),
            const SizedBox(height: 12),
            CustomButton(
              text: 'Scan Another QR',
              icon: Icons.qr_code_scanner,
              onPressed: _resetScan,
              backgroundColor: Colors.grey,
            ),
          ] else ...[
            CustomButton(
              text: 'Go to Dashboard',
              icon: Icons.dashboard,
              onPressed: () {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const AdminDashboard()),
                  (route) => false,
                );
              },
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 20, color: AppColors.textSecondary),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  color: AppColors.textSecondary,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 15,
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  void _onQRViewCreated(QRViewController controller) {
    this.controller = controller;
    controller.scannedDataStream.listen((scanData) {
      if (isScanning && scanData.code != null) {
        setState(() => isScanning = false);
        controller.pauseCamera();
        _handleQRScan(scanData.code!);
      }
    });
  }

  Future<void> _handleQRScan(String qrCode) async {
    setState(() => isLoading = true);

    try {
      final organizationProvider = Provider.of<OrganizationProvider>(context, listen: false);
      
      // Look up organization by QR ID
      final organization = await organizationProvider.getOrganizationByQr(qrCode);

      if (organization != null) {
        setState(() {
          scannedOrganization = organization;
          isLoading = false;
        });
      } else {
        if (mounted) {
          UIHelper.showErrorDialog(context, 'Invalid QR code or organization not found');
          _resetScan();
        }
      }
    } catch (e) {
      print('❌ QR scan error: $e');
      if (mounted) {
        UIHelper.showErrorDialog(context, 'Failed to lookup organization');
        _resetScan();
      }
    } finally {
      if (mounted) {
        setState(() => isLoading = false);
      }
    }
  }

  Future<void> _handleSendJoinRequest() async {
    if (scannedOrganization == null) return;

    setState(() => isLoading = true);

    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final organizationProvider = Provider.of<OrganizationProvider>(context, listen: false);

      final currentUser = authProvider.currentUser;
      if (currentUser == null) {
        throw Exception('User not logged in');
      }

      final success = await organizationProvider.sendJoinRequest(
        userId: currentUser.uid,
        organizationId: scannedOrganization!.organizationId,
      );

      if (!mounted) return;

      if (success) {
        setState(() => requestSent = true);
        UIHelper.showSnackBar(
          context,
          'Join request sent successfully!',
        );
      } else {
        UIHelper.showSnackBar(
          context,
          organizationProvider.error ?? 'Failed to send join request',
          isError: true,
        );
      }
    } catch (e) {
      print('❌ Send join request error: $e');
      if (mounted) {
        UIHelper.showSnackBar(
          context,
          'Error: ${e.toString()}',
          isError: true,
        );
      }
    } finally {
      if (mounted) {
        setState(() => isLoading = false);
      }
    }
  }

  void _resetScan() {
    setState(() {
      scannedOrganization = null;
      isScanning = true;
      requestSent = false;
    });
    controller?.resumeCamera();
  }
}
