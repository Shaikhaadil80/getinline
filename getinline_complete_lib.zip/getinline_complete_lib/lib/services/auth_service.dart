// =============================================================================
// GETINLINE FLUTTER - services/auth_service.dart
// Firebase Authentication Service with Google & Apple Sign-In
// =============================================================================

import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'dart:io';
import 'api_service.dart';
import 'database_service.dart';
import '../utils/constants.dart';

class AuthService {
  // Singleton pattern
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final ApiService _apiService = ApiService();
  final DatabaseService _dbService = DatabaseService();

  // Get current user
  User? get currentUser => _auth.currentUser;

  // Get current user UID
  String? get currentUserUid => _auth.currentUser?.uid;

  // Check if user is signed in
  bool get isSignedIn => _auth.currentUser != null;

  // Auth state stream
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // =============================================================================
  // GOOGLE SIGN-IN
  // =============================================================================

  Future<UserCredential?> signInWithGoogle() async {
    try {
      print('🔐 Starting Google Sign-In...');
      
      // Trigger the authentication flow
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      
      if (googleUser == null) {
        print('❌ Google Sign-In cancelled by user');
        return null;
      }

      print('✅ Google account selected: ${googleUser.email}');

      // Obtain the auth details from the request
      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;

      // Create a new credential
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // Sign in to Firebase with the Google credential
      final userCredential = await _auth.signInWithCredential(credential);
      
      print('✅ Firebase sign-in successful: ${userCredential.user?.uid}');
      
      // Save UID locally
      if (userCredential.user != null) {
        await _dbService.saveUserUid(userCredential.user!.uid);
      }

      return userCredential;
    } catch (e) {
      print('❌ Google Sign-In error: $e');
      throw AuthException('Google Sign-In failed: $e');
    }
  }

  // =============================================================================
  // APPLE SIGN-IN
  // =============================================================================

  Future<UserCredential?> signInWithApple() async {
    try {
      // Check if Apple Sign In is available
      if (!Platform.isIOS && !Platform.isMacOS) {
        throw AuthException('Apple Sign-In is only available on iOS and macOS');
      }

      print('🔐 Starting Apple Sign-In...');

      // Request credential
      final appleCredential = await SignInWithApple.getAppleIDCredential(
        scopes: [
          AppleIDAuthorizationScopes.email,
          AppleIDAuthorizationScopes.fullName,
        ],
      );

      print('✅ Apple credential received');

      // Create OAuth credential
      final oauthCredential = OAuthProvider("apple.com").credential(
        idToken: appleCredential.identityToken,
        accessToken: appleCredential.authorizationCode,
      );

      // Sign in to Firebase with the Apple credential
      final userCredential = await _auth.signInWithCredential(oauthCredential);
      
      print('✅ Firebase sign-in successful: ${userCredential.user?.uid}');
      
      // Save UID locally
      if (userCredential.user != null) {
        await _dbService.saveUserUid(userCredential.user!.uid);
      }

      return userCredential;
    } catch (e) {
      print('❌ Apple Sign-In error: $e');
      throw AuthException('Apple Sign-In failed: $e');
    }
  }

  // =============================================================================
  // EMAIL/PASSWORD SIGN-IN (Optional)
  // =============================================================================

  Future<UserCredential> signInWithEmailPassword(String email, String password) async {
    try {
      print('🔐 Signing in with email: $email');
      
      final userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      print('✅ Email sign-in successful: ${userCredential.user?.uid}');
      
      // Save UID locally
      if (userCredential.user != null) {
        await _dbService.saveUserUid(userCredential.user!.uid);
      }
      
      return userCredential;
    } on FirebaseAuthException catch (e) {
      print('❌ Email sign-in error: ${e.code}');
      
      switch (e.code) {
        case 'user-not-found':
          throw AuthException('No user found with this email');
        case 'wrong-password':
          throw AuthException('Incorrect password');
        case 'invalid-email':
          throw AuthException('Invalid email address');
        case 'user-disabled':
          throw AuthException('This account has been disabled');
        default:
          throw AuthException('Sign-in failed: ${e.message}');
      }
    }
  }

  Future<UserCredential> signUpWithEmailPassword(
    String email,
    String password,
  ) async {
    try {
      print('🔐 Creating account with email: $email');
      
      final userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      print('✅ Account created successfully: ${userCredential.user?.uid}');
      
      // Save UID locally
      if (userCredential.user != null) {
        await _dbService.saveUserUid(userCredential.user!.uid);
      }
      
      return userCredential;
    } on FirebaseAuthException catch (e) {
      print('❌ Sign-up error: ${e.code}');
      
      switch (e.code) {
        case 'email-already-in-use':
          throw AuthException('An account already exists with this email');
        case 'invalid-email':
          throw AuthException('Invalid email address');
        case 'weak-password':
          throw AuthException('Password is too weak');
        default:
          throw AuthException('Sign-up failed: ${e.message}');
      }
    }
  }

  // =============================================================================
  // SIGN OUT
  // =============================================================================

  Future<void> signOut() async {
    try {
      print('🔐 Signing out...');
      
      // Sign out from Firebase
      await _auth.signOut();
      
      // Sign out from Google if signed in
      if (await _googleSignIn.isSignedIn()) {
        await _googleSignIn.signOut();
      }
      
      // Clear local storage
      await _dbService.clearUserData();
      
      print('✅ Sign-out successful');
    } catch (e) {
      print('❌ Sign-out error: $e');
      throw AuthException('Sign-out failed: $e');
    }
  }

  // =============================================================================
  // USER MANAGEMENT
  // =============================================================================

  // Get current user token
  Future<String?> getCurrentUserToken() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return null;
      
      final token = await user.getIdToken();
      
      // Save token locally
      if (token != null) {
        await _dbService.saveUserToken(token);
        await _apiService.setAuthToken(token);
      }
      
      return token;
    } catch (e) {
      print('❌ Error getting user token: $e');
      return null;
    }
  }

  // Refresh user token
  Future<String?> refreshToken() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return null;
      
      final token = await user.getIdToken(true); // Force refresh
      
      // Save token locally
      if (token != null) {
        await _dbService.saveUserToken(token);
        await _apiService.setAuthToken(token);
      }
      
      return token;
    } catch (e) {
      print('❌ Error refreshing token: $e');
      return null;
    }
  }

  // Update user profile
  Future<void> updateUserProfile({String? displayName, String? photoURL}) async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        throw AuthException('No user signed in');
      }

      await user.updateDisplayName(displayName);
      await user.updatePhotoURL(photoURL);
      await user.reload();
      
      print('✅ User profile updated');
    } catch (e) {
      print('❌ Error updating profile: $e');
      throw AuthException('Failed to update profile: $e');
    }
  }

  // Send email verification
  Future<void> sendEmailVerification() async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        throw AuthException('No user signed in');
      }

      if (!user.emailVerified) {
        await user.sendEmailVerification();
        print('✅ Verification email sent');
      }
    } catch (e) {
      print('❌ Error sending verification email: $e');
      throw AuthException('Failed to send verification email: $e');
    }
  }

  // Send password reset email
  Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
      print('✅ Password reset email sent to: $email');
    } on FirebaseAuthException catch (e) {
      print('❌ Password reset error: ${e.code}');
      
      switch (e.code) {
        case 'user-not-found':
          throw AuthException('No user found with this email');
        case 'invalid-email':
          throw AuthException('Invalid email address');
        default:
          throw AuthException('Failed to send reset email: ${e.message}');
      }
    }
  }

  // Delete user account
  Future<void> deleteAccount() async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        throw AuthException('No user signed in');
      }

      await user.delete();
      await _dbService.clearUserData();
      
      print('✅ Account deleted');
    } catch (e) {
      print('❌ Error deleting account: $e');
      throw AuthException('Failed to delete account: $e');
    }
  }

  // Re-authenticate user (required before sensitive operations)
  Future<void> reauthenticateWithGoogle() async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        throw AuthException('No user signed in');
      }

      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return;

      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      await user.reauthenticateWithCredential(credential);
      print('✅ Re-authentication successful');
    } catch (e) {
      print('❌ Re-authentication error: $e');
      throw AuthException('Re-authentication failed: $e');
    }
  }
}

// =============================================================================
// CUSTOM EXCEPTION
// =============================================================================

class AuthException implements Exception {
  final String message;
  AuthException(this.message);
  
  @override
  String toString() => message;
}
